package conexion;
import java.sql.DriverManager;
import java.sql.SQLException;
// package: com.mycompany.physicmanages.connection
public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3306/physicdb";
    private static final String USER = "root";
    private static final String PASS = "tu_clave";

    public static Conexion getConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return (Conexion) DriverManager.getConnection(URL, USER, PASS);
        } catch (ClassNotFoundException | SQLException e) {
            return null;
        }
    }
}
