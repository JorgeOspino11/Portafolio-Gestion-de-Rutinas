package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

    public class ConexionBD {
        private static final String URL = "jdbc:mysql://localhost:3306/physicmanages";
        private static final String USUARIO = "root";
        private static final String CONTRASENA = "1234";

        public static Connection getConexion() {
            Connection conexion = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
                System.out.println("✅ Conexión exitosa a la base de datos.");
            } catch (ClassNotFoundException | SQLException e) {
                System.err.println("❌ Error de conexión: " + e.getMessage());
            }
            return conexion;
        }

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }
