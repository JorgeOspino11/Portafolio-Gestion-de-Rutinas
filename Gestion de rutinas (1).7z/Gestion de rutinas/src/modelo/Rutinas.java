package modelo;

public class Rutinas {
    private int id;
    private int clienteId;
    private String nombre;
    private String descripcion;
    private String horario;

    public Rutinas() {}

    public Rutinas(int id, int clienteId, String nombre, String descripcion, String horario) {
        this.id = id;
        this.clienteId = clienteId;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.horario = horario;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }
}
