package controlador;

import modelo.Cliente;
import interfaces.ClienteDAO;
import java.util.List;

public class ClienteController {
    private final ClienteDAO ClienteDAO = new ClienteDAO();

    public boolean registrarCliente(Cliente cliente) {
        return ClienteDAO.registrarCliente(cliente);
    }

    public List<Cliente> listarClientes() {
        return ClienteDAO.obtenerClientes();
    }

    public boolean actualizarCliente(Cliente cliente) {
        return ClienteDAO.actualizarCliente(cliente);
    }

    public boolean eliminarCliente(int id) {
        return ClienteDAO.eliminarCliente(id);
    }
}