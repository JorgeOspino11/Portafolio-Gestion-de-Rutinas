package DAO;

import BaseDatos.ConexionBD;
import modelo.Progreso;
///////// PAQUETES /////////
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgresoDAO {

    public boolean insertar(Progreso progreso) {
        String sql = "INSERT INTO progreso (fecha, peso, medida_cintura, usuario_id) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, new java.sql.Date(progreso.getFecha().getTime()));
            ps.setBigDecimal(2, progreso.getPeso());
            ps.setBigDecimal(3, progreso.getMedidaCintura());
            ps.setInt(4, progreso.getUsuarioId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Progreso> getAll() {
        List<Progreso> lista = new ArrayList<>();
        String sql = "SELECT * FROM progreso";

        try (Connection con = ConexionBD.getInstancia().conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Progreso p = new Progreso();
                p.setId(rs.getInt("id"));
                p.setFecha(rs.getDate("fecha"));
                p.setPeso(rs.getBigDecimal("peso"));
                p.setMedidaCintura(rs.getBigDecimal("medida_cintura"));
                p.setUsuarioId(rs.getInt("usuario_id"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean actualizar(Progreso progreso) {
        String sql = "UPDATE progreso SET fecha = ?, peso = ?, medida_cintura = ?, usuario_id = ? WHERE id = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, new java.sql.Date(progreso.getFecha().getTime()));
            ps.setBigDecimal(2, progreso.getPeso());
            ps.setBigDecimal(3, progreso.getMedidaCintura());
            ps.setInt(4, progreso.getUsuarioId());
            ps.setInt(5, progreso.getId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM progreso WHERE id = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
