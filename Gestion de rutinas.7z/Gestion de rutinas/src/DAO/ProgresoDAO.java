package dao;

import BaseDatos.ConexionBD;
import modelo.Progreso;
///////////////////////////
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgresoDAO {

    public boolean insertar(Progreso progreso) {
        String sql = "INSERT INTO progresos (fecha, peso, porcentaje_grasa, usuario_id) VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionBD.obtenerConexion();
            PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, progreso.getFecha());
            ps.setDouble(2, progreso.getPeso());
            ps.setDouble(3, progreso.getPorcentajeGrasa());
            ps.setInt(4, progreso.getUsuarioId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Progreso> getAll() {
        List<Progreso> lista = new ArrayList<>();
        String sql = "SELECT * FROM progresos";
        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Progreso p = new Progreso(
                    rs.getInt("id"),
                    rs.getString("fecha"),
                    rs.getDouble("peso"),
                    rs.getDouble("porcentaje_grasa"),
                    rs.getInt("usuario_id")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean actualizar(Progreso progreso) {
        String sql = "UPDATE progresos SET fecha = ?, peso = ?, porcentaje_grasa = ?, usuario_id = ? WHERE id = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, progreso.getFecha());
            ps.setDouble(2, progreso.getPeso());
            ps.setDouble(3, progreso.getPorcentajeGrasa());
            ps.setInt(4, progreso.getUsuarioId());
            ps.setInt(5, progreso.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM progresos WHERE id = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
