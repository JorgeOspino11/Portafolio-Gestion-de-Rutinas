package DAO;

import BaseDatos.ConexionBD;
import modelo.Categoria;
///////// PAQUETES /////////
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CategoriaDAO {

    private final Connection conexion;

    // Constructor que establece la conexión al crearse la instancia del DAO
    public CategoriaDAO() {
        this.conexion = ConexionBD.getInstancia().conectar();
    }

    // Método para insertar una nueva categoría
    public boolean insertar(Categoria categoria) {
        String sql = "INSERT INTO categoria (nombre) VALUES (?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, categoria.getNombre());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    // Método para obtener todas las categorías
    public List<Categoria> listar() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM categoria";
        try (Statement stmt = conexion.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Categoria cat = new Categoria();
                cat.setIdCategoria(rs.getInt("idCategoria"));
                cat.setNombre(rs.getString("nombre"));
                lista.add(cat);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al listar categorías: " + e.getMessage());
        }
        return lista;
    }

    // Método para actualizar una categoría existente
    public boolean actualizar(Categoria categoria) {
        String sql = "UPDATE categoria SET nombre=? WHERE idCategoria=?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, categoria.getNombre());
            stmt.setInt(2, categoria.getIdCategoria());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar categoría: " + e.getMessage());
            return false;
        }
    }

    // Método para eliminar una categoría por su ID
    public boolean eliminar(int idCategoria) {
        String sql = "DELETE FROM categoria WHERE idCategoria=?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idCategoria);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar categoría: " + e.getMessage());
            return false;
        }
    }

    // Método para buscar una categoría por ID
    public Categoria buscarPorId(int idCategoria) {
        String sql = "SELECT * FROM categoria WHERE idCategoria=?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, idCategoria);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Categoria(rs.getInt("idCategoria"), rs.getString("nombre"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar categoría: " + e.getMessage());
        }
        return null;
    }
}

