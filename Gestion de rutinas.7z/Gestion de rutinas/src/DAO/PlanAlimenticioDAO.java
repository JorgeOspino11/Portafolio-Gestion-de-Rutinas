package dao;

import BaseDatos.ConexionBD;
import modelo.PlanAlimenticio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PlanAlimenticioDAO {

    private final Connection conexion;

    // Constructor que obtiene la conexión a la base de datos
    public PlanAlimenticioDAO() {
        this.conexion = ConexionBD.getInstancia().conectar();
    }

    // Insertar un nuevo plan alimenticio
    public boolean insertar(PlanAlimenticio plan) {
        String sql = "INSERT INTO plan_alimenticio (descripcion, usuario_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, plan.getDescripcion());
            stmt.setInt(2, plan.getUsuarioId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar plan alimenticio: " + e.getMessage());
            return false;
        }
    }

    // Obtener todos los planes alimenticios
    public List<PlanAlimenticio> listar() {
        List<PlanAlimenticio> lista = new ArrayList<>();
        String sql = "SELECT * FROM plan_alimenticio";
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                PlanAlimenticio plan = new PlanAlimenticio();
                plan.setId(rs.getInt("id"));
                plan.setDescripcion(rs.getString("descripcion"));
                plan.setUsuarioId(rs.getInt("usuario_id"));
                lista.add(plan);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al listar planes alimenticios: " + e.getMessage());
        }
        return lista;
    }

    // Actualizar un plan alimenticio existente
    public boolean actualizar(PlanAlimenticio plan) {
        String sql = "UPDATE plan_alimenticio SET descripcion = ?, usuario_id = ? WHERE id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, plan.getDescripcion());
            stmt.setInt(2, plan.getUsuarioId());
            stmt.setInt(3, plan.getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar plan alimenticio: " + e.getMessage());
            return false;
        }
    }

    // Eliminar un plan alimenticio por su ID
    public boolean eliminar(int id) {
        String sql = "DELETE FROM plan_alimenticio WHERE id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar plan alimenticio: " + e.getMessage());
            return false;
        }
    }

    // Buscar un plan alimenticio por ID
    public PlanAlimenticio buscarPorId(int id) {
        String sql = "SELECT * FROM plan_alimenticio WHERE id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new PlanAlimenticio(
                    rs.getInt("id"),
                    rs.getString("descripcion"),
                    rs.getInt("usuario_id")
                );
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar plan alimenticio: " + e.getMessage());
        }
        return null;
    }
}
