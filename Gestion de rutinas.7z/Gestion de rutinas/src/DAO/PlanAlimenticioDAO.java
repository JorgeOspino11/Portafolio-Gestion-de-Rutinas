package dao;

import conexion.ConexionBD;
import modelo.PlanAlimenticio;
//////////////////////////////
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanAlimenticioDAO {

    public boolean insertar(PlanAlimenticio plan) {
        String sql = "INSERT INTO planes_alimenticios (descripcion, usuario_id) VALUES (?, ?)";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, plan.getDescripcion());
            ps.setInt(2, plan.getUsuarioId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<PlanAlimenticio> getAll() {
        List<PlanAlimenticio> lista = new ArrayList<>();
        String sql = "SELECT * FROM planes_alimenticios";
        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                PlanAlimenticio plan = new PlanAlimenticio(
                    rs.getInt("id"),
                    rs.getString("descripcion"),
                    rs.getInt("usuario_id")
                );
                lista.add(plan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean actualizar(PlanAlimenticio plan) {
        String sql = "UPDATE planes_alimenticios SET descripcion = ?, usuario_id = ? WHERE id = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, plan.getDescripcion());
            ps.setInt(2, plan.getUsuarioId());
            ps.setInt(3, plan.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM planes_alimenticios WHERE id = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
