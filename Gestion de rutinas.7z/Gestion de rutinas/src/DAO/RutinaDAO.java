package DAO;

import BaseDatos.ConexionBD;
import modelo.Rutina;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAO {

    public boolean insertar(Rutina rutina) {
        String sql = "INSERT INTO rutina (nombre, descripcion, usuario_id) VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rutina.getNombre());
            ps.setString(2, rutina.getDescripcion());
            ps.setInt(3, rutina.getUsuarioId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Rutina> getAll() {
        List<Rutina> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutina";
        try (Connection con = ConexionBD.getInstancia().conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Rutina rutina = new Rutina(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("usuario_id")
                );
                lista.add(rutina);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean actualizar(Rutina rutina) {
        String sql = "UPDATE rutina SET nombre = ?, descripcion = ?, usuario_id = ? WHERE id = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rutina.getNombre());
            ps.setString(2, rutina.getDescripcion());
            ps.setInt(3, rutina.getUsuarioId());
            ps.setInt(4, rutina.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM rutina WHERE id = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
