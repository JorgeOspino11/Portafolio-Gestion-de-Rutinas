package controllers;

import models.Usuario;
import models.UsuarioDAO;

public class UsuarioController {
    private final UsuarioDAO UsuarioDAO = new UsuarioDAO();

    public boolean login(String usuario, String clave) {
        Usuario user = new Usuario();
        user.setUsuario(usuario);
        user.setClave(clave);
        return UsuarioDAO.validarUsuario(user);
    }

    public boolean registrar(String usuario, String clave) {
        Usuario user = new Usuario();
        user.setUsuario(usuario);
        user.setClave(clave);
        return UsuarioDAO.registrarUsuario(user);
    }
}