package modelo;

public class PlanAlimenticio {
    private int id;
    private String descripcion;
    private int usuarioId;

    public PlanAlimenticio() {
    }

    public PlanAlimenticio(int id, String descripcion, int usuarioId) {
        this.id = id;
        this.descripcion = descripcion;
        this.usuarioId = usuarioId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
