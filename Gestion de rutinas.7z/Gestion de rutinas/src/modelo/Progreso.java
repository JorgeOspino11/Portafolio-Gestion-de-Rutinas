package modelo;

public class Progreso {
    private int id;
    private String fecha;
    private double peso;
    private double grasaCorporal;
    private int usuarioId;

    public Progreso() {
    }

    public Progreso(int id, String fecha, double peso, double grasaCorporal, int usuarioId) {
        this.id = id;
        this.fecha = fecha;
        this.peso = peso;
        this.grasaCorporal = grasaCorporal;
        this.usuarioId = usuarioId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getGrasaCorporal() {
        return grasaCorporal;
    }

    public void setGrasaCorporal(double grasaCorporal) {
        this.grasaCorporal = grasaCorporal;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public double getPorcentajeGrasa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
