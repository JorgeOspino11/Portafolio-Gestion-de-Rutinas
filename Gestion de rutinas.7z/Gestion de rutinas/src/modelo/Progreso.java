package modelo;

import java.math.BigDecimal;
import java.util.Date;

public class Progreso {
    private int id;
    private Date fecha;
    private BigDecimal peso;
    private BigDecimal medidaCintura;
    private int usuarioId;

    // Constructor vacío
    public Progreso() {
    }

    // Constructor con todos los campos
    public Progreso(int id, Date fecha, BigDecimal peso, BigDecimal medidaCintura, int usuarioId) {
        this.id = id;
        this.fecha = fecha;
        this.peso = peso;
        this.medidaCintura = medidaCintura;
        this.usuarioId = usuarioId;
    }

    // Getters y setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public BigDecimal getMedidaCintura() {
        return medidaCintura;
    }

    public void setMedidaCintura(BigDecimal medidaCintura) {
        this.medidaCintura = medidaCintura;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
