package PhysicManages;

import vista.LoginForm;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class PhysicManages {
    public static void main(String[] args) {
        try {
            // Estilo visual (opcional)
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
        }

        // Iniciar la aplicación con el formulario de login
        java.awt.EventQueue.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
