package interfaces;

import java.sql.*;
import java.util.*;
import BaseDatos.ConexionBD;
import modelo.Rutina;

public class RutinasDAO {

    public static boolean registrarRutina(Rutina rutina) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private final Connection con;

    public RutinasDAO() {
        con = ConexionBD.getConnection();
    }

    public boolean insertar(Rutina rutina) {
        String sql = "INSERT INTO rutinas (clienteId, nombre, descripcion, horario) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, rutina.getClienteId());
            ps.setString(2, rutina.getNombre());
            ps.setString(3, rutina.getDescripcion());
            ps.setString(4, rutina.getHorario());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar rutina: " + e);
            return false;
        }
    }

    public List<Rutina> listar() {
        List<Rutina> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutinas";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Rutina r = new Rutina(
                    rs.getInt("id"),
                    rs.getInt("clienteId"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getString("horario")
                );
                lista.add(r);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar rutinas: " + e);
        }
        return lista;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM rutinas WHERE id=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar rutina: " + e);
            return false;
        }
    }

    public boolean actualizar(Rutina rutina) {
        String sql = "UPDATE rutinas SET clienteId=?, nombre=?, descripcion=?, horario=? WHERE id=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, rutina.getClienteId());
            ps.setString(2, rutina.getNombre());
            ps.setString(3, rutina.getDescripcion());
            ps.setString(4, rutina.getHorario());
            ps.setInt(5, rutina.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar rutina: " + e);
            return false;
        }
    }

    public List<Rutina> obtenerRutinasPorCliente(int clienteId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean actualizarRutina(Rutina rutina) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean eliminarRutina(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
