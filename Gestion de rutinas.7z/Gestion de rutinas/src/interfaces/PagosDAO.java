package interfaces;

import java.sql.*;
import java.util.*;
import conexion.ConexionBD;
import modelo.Pagos;

public class PagosDAO {

    private final Connection con;

    public PagosDAO() {
        con = ConexionBD.getConnection();
    }

    public boolean insertar(Pagos pago) {
        String sql = "INSERT INTO pagos (clienteId, monto, fecha) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, pago.getClienteId());
            ps.setDouble(2, pago.getMonto());
            ps.setDate(3, new java.sql.Date(pago.getFecha().getTime()));
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar pago: " + e);
            return false;
        }
    }

    public List<Pagos> listar() {
        List<Pagos> lista = new ArrayList<>();
        String sql = "SELECT * FROM pagos";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Pagos p = new Pagos(
                    rs.getInt("id"),
                    rs.getInt("clienteId"),
                    rs.getDouble("monto"),
                    rs.getDate("fecha")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar pagos: " + e);
        }
        return lista;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM pagos WHERE id=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar pago: " + e);
            return false;
        }
    }

    /**
     *
     * @param pago
     * @return
     */
    public boolean actualizar(Pagos pago) {
        String sql = "UPDATE pagos SET clienteId=?, monto=?, fecha=? WHERE id=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, pago.getClienteId());
            ps.setDouble(2, pago.getMonto());
            ps.setDate(3, new java.sql.Date(pago.getFecha().getTime()));
            ps.setInt(4, pago.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar pago: " + e);
            return false;
        }
    }

    public boolean registrarPago(Pagos pago) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Pagos> obtenerPagosPorCliente(int clienteId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean actualizarPago(Pagos pago) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean eliminarPago(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
