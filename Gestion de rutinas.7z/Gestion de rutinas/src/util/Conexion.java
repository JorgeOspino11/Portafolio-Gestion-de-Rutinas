package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection getConexion() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/tu_basededatos";
        String user = "root";
        String pass = "tu_contraseña";
        return DriverManager.getConnection(url, user, pass);
    }
}
