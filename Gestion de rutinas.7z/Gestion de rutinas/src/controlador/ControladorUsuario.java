package controlador;

import DAO.UsuarioDAO;
import dao.DAOUsuarioImpl;
import modelo.Usuario;
import java.util.List;

public class ControladorUsuario {
    private final UsuarioDAO daoUsuario;

    public ControladorUsuario() {
        daoUsuario = new DAOUsuarioImpl();
    }

    // Iniciar sesión con email y password
    public boolean iniciarSesion(String email, String password) {
        Usuario usuario = daoUsuario.obtenerPorEmail(email);
        return usuario != null && usuario.getPassword().equals(password);
    }

    // Registrar un nuevo usuario
    public boolean registrarUsuario(Usuario usuario) {
        return daoUsuario.agregarUsuario(usuario);
    }

    // Actualizar datos del usuario
    public boolean actualizarUsuario(Usuario usuario) {
        return daoUsuario.actualizarUsuario(usuario);
    }

    // Obtener un usuario por su ID
    public Usuario obtenerUsuarioPorId(int id) {
        return daoUsuario.obtenerPorId(id);
    }

    // Obtener todos los usuarios (para administración, por ejemplo)
    public List<Usuario> obtenerTodosLosUsuarios() {
        return daoUsuario.obtenerTodos();
    }
}
