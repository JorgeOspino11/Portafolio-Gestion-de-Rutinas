package modelo;
//Autor: Jorge Ospino.
import java.math.BigDecimal;
import java.util.*;

public class Progreso {
    private int id;
    private Date fecha;
    private double peso;
    private double grasaCorporal;
    private double masaMuscular;
    private int usuarioId;

    // Constructor vacío
    public Progreso() {
    }

    // Constructor con ID (útil para consultar o actualizar)
    public Progreso(int id, Date fecha, double peso, double grasaCorporal, double masaMuscular, int usuarioId) {
        this.id = id;
        this.fecha = fecha;
        this.peso = peso;
        this.grasaCorporal = grasaCorporal;
        this.masaMuscular = masaMuscular;
        this.usuarioId = usuarioId;
    }

    // Constructor sin ID (útil para insertar nuevos progresos)
    public Progreso(Date fecha, double peso, double grasaCorporal, double masaMuscular, int usuarioId) {
        this.fecha = fecha;
        this.peso = peso;
        this.grasaCorporal = grasaCorporal;
        this.masaMuscular = masaMuscular;
        this.usuarioId = usuarioId;
    }

    public Progreso(int aInt, double aDouble, int aInt0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getGrasaCorporal() {
        return grasaCorporal;
    }

    public void setGrasaCorporal(double grasaCorporal) {
        this.grasaCorporal = grasaCorporal;
    }

    public double getMasaMuscular() {
        return masaMuscular;
    }

    public void setMasaMuscular(double masaMuscular) {
        this.masaMuscular = masaMuscular;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public BigDecimal getMedidaCintura() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setMedidaCintura(BigDecimal bigDecimal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double getAltura() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getIdProgreso() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

