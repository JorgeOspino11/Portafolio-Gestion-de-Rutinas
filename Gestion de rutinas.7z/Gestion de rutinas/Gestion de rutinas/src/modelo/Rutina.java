package modelo;
//Autor: Jorge Ospino.
public class Rutina {
    private int id;
    private String nombre;
    private String descripcion;
    private int categoriaId;
    private int usuarioId;
    private String diaSemana;

    // Constructor vacío
    public Rutina() {
    }

    // Constructor con ID
    public Rutina(int id, String nombre, String descripcion, int categoriaId, int usuarioId, String diaSemana) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoriaId = categoriaId;
        this.usuarioId = usuarioId;
        this.diaSemana = diaSemana;
    }

    // Constructor sin ID (para insertar)
    public Rutina(String nombre, String descripcion, int categoriaId, int usuarioId, String diaSemana) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoriaId = categoriaId;
        this.usuarioId = usuarioId;
        this.diaSemana = diaSemana;
    }

    public Rutina(int aInt, String string, String string0, int aInt0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(int categoriaId) {
        this.categoriaId = categoriaId;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana;
    }

    public int getIdRutina() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
