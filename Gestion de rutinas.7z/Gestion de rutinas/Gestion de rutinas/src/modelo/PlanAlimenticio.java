package modelo;
// Autor: Jorge Ospino.
public class PlanAlimenticio {
    private int id;
    private String descripcion;
    private int usuarioId;

    // Constructor vacío
    public PlanAlimenticio() {
    }

    // Constructor con ID (para actualizar o consultar)
    public PlanAlimenticio(int id, String descripcion, int usuarioId) {
        this.id = id;
        this.descripcion = descripcion;
        this.usuarioId = usuarioId;
    }

    // Constructor sin ID (para insertar)
    public PlanAlimenticio(String descripcion, int usuarioId) {
        this.descripcion = descripcion;
        this.usuarioId = usuarioId;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
