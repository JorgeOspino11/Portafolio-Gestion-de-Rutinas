package DAO;
//Autor: Jorge Ospino.
import BaseDatos.ConexionBD;
import modelo.Progreso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgresoDAO {

    public boolean insertar(Progreso progreso) {
        String sql = "INSERT INTO progreso (peso, altura, grasa_corporal, fecha, usuario_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, progreso.getPeso());
            ps.setDouble(2, progreso.getAltura());
            ps.setInt(5, progreso.getUsuarioId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error insertando progreso: " + e.getMessage());
            return false;
        }
    }

    public List<Progreso> getAll() {
        List<Progreso> lista = new ArrayList<>();
        String sql = "SELECT * FROM progreso";

        try (Connection con = ConexionBD.getInstancia().conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Progreso p = new Progreso(
                    rs.getInt("id_progreso"),
                    rs.getDouble("peso"),
                    rs.getInt("usuario_id")
                );
                lista.add(p);
            }

        } catch (SQLException e) {
            System.err.println("Error obteniendo progresos: " + e.getMessage());
        }

        return lista;
    }

    public boolean actualizar(Progreso progreso) {
        String sql = "UPDATE progreso SET peso = ?, altura = ?, grasa_corporal = ?, fecha = ?, usuario_id = ? WHERE id_progreso = ?";

        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, progreso.getPeso());
            ps.setDouble(2, progreso.getAltura());
            ps.setInt(5, progreso.getUsuarioId());
            ps.setInt(6, progreso.getIdProgreso());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error actualizando progreso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idProgreso) {
        String sql = "DELETE FROM progreso WHERE id_progreso = ?";

        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idProgreso);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error eliminando progreso: " + e.getMessage());
            return false;
        }
    }
}
