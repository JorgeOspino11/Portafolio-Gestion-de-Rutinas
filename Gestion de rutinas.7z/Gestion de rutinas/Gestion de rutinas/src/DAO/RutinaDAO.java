package DAO;
//Autor: Jorge Ospino.
import BaseDatos.ConexionBD;
import modelo.Rutina;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAO {

    public boolean insertar(Rutina rutina) {
        String sql = "INSERT INTO rutinas (nombre, descripcion, usuario_id) VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rutina.getNombre());
            ps.setString(2, rutina.getDescripcion());
            ps.setInt(3, rutina.getUsuarioId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error insertando rutina: " + e.getMessage());
            return false;
        }
    }

    public List<Rutina> getAll() {
        List<Rutina> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutinas";
        try (Connection con = ConexionBD.getInstancia().conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Rutina rutina = new Rutina(
                    rs.getInt("id_rutina"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getInt("usuario_id")
                );
                lista.add(rutina);
            }

        } catch (SQLException e) {
            System.err.println("Error obteniendo rutinas: " + e.getMessage());
        }
        return lista;
    }

    public boolean actualizar(Rutina rutina) {
        String sql = "UPDATE rutinas SET nombre = ?, descripcion = ?, usuario_id = ? WHERE id_rutina = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rutina.getNombre());
            ps.setString(2, rutina.getDescripcion());
            ps.setInt(3, rutina.getUsuarioId());
            ps.setInt(4, rutina.getIdRutina());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error actualizando rutina: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idRutina) {
        String sql = "DELETE FROM rutinas WHERE id_rutina = ?";
        try (Connection con = ConexionBD.getInstancia().conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idRutina);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error eliminando rutina: " + e.getMessage());
            return false;
        }
    }
}
