package controlador;

import DAO.PlanAlimenticioDAO;
import modelo.PlanAlimenticio;

import java.util.List;

public class PlanAlimenticioControlador {
    private PlanAlimenticioDAO planDAO;

    public PlanAlimenticioControlador() {
        planDAO = new PlanAlimenticioDAO();
    }

    // Registrar nuevo plan alimenticio
    public boolean registrarPlan(PlanAlimenticio plan) {
        return planDAO.insertar(plan);
    }

    // Obtener todos los planes
    public List<PlanAlimenticio> obtenerPlanes() {
        return planDAO.getAll();
    }

    // Actualizar un plan alimenticio
    public boolean actualizarPlan(PlanAlimenticio plan) {
        return planDAO.actualizar(plan);
    }

    // Eliminar plan alimenticio por ID
    public boolean eliminarPlan(int id) {
        return planDAO.eliminar(id);
    }

    // Buscar un plan por ID (opcional)
    public PlanAlimenticio obtenerPlanPorId(int id) {
        List<PlanAlimenticio> planes = planDAO.getAll();
        for (PlanAlimenticio p : planes) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }
}
