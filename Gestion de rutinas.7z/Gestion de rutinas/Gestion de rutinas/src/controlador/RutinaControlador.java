package controlador;

import DAO.RutinaDAO;
import modelo.Rutina;

import java.util.List;

public class RutinaControlador {
    private RutinaDAO rutinaDAO;

    public RutinaControlador() {
        rutinaDAO = new RutinaDAO();
    }

    // Registrar nueva rutina
    public boolean registrarRutina(Rutina rutina) {
        return rutinaDAO.insertar(rutina);
    }

    // Obtener todas las rutinas
    public List<Rutina> obtenerRutinas() {
        return rutinaDAO.getAll();
    }

    // Actualizar rutina existente
    public boolean actualizarRutina(Rutina rutina) {
        return rutinaDAO.actualizar(rutina);
    }

    // Eliminar rutina por ID
    public boolean eliminarRutina(int id) {
        return rutinaDAO.eliminar(id);
    }

    // Buscar rutina por ID (opcional)
    public Rutina obtenerRutinaPorId(int id) {
        List<Rutina> rutinas = rutinaDAO.getAll();
        for (Rutina r : rutinas) {
            if (r.getId() == id) {
                return r;
            }
        }
        return null;
    }
}
