package controlador;

import DAO.ProgresoDAO;
import modelo.Progreso;

import java.util.List;

public class ProgresoControlador {
    private ProgresoDAO progresoDAO;

    public ProgresoControlador() {
        progresoDAO = new ProgresoDAO();
    }

    // Registrar nuevo progreso
    public boolean registrarProgreso(Progreso progreso) {
        return progresoDAO.insertar(progreso);
    }

    // Obtener todos los registros de progreso
    public List<Progreso> obtenerProgresos() {
        return progresoDAO.getAll();
    }

    // Actualizar un registro de progreso
    public boolean actualizarProgreso(Progreso progreso) {
        return progresoDAO.actualizar(progreso);
    }

    // Eliminar un progreso por ID
    public boolean eliminarProgreso(int id) {
        return progresoDAO.eliminar(id);
    }

    // Buscar progreso por ID
    public Progreso obtenerProgresoPorId(int id) {
        List<Progreso> lista = progresoDAO.getAll();
        for (Progreso p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }
}

