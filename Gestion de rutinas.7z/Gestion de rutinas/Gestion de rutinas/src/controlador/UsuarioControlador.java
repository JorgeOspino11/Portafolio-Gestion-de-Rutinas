package controlador;
//Autor: Jorge Ospino.
import DAO.UsuarioDAO;
import modelo.Usuario;

import java.util.List;

public class UsuarioControlador {
    private UsuarioDAO UsuarioDAO;

    public UsuarioControlador() {
        UsuarioDAO = new UsuarioDAO();
    }

    // Insertar nuevo usuario
    public boolean registrarUsuario(Usuario usuario) {
        return UsuarioDAO.insertar(usuario);
    }

    // Obtener lista de usuarios
    public List<Usuario> obtenerUsuarios() {
        return UsuarioDAO.getAll();
    }

    // Actualizar usuario
    public boolean actualizarUsuario(Usuario usuario) {
        return UsuarioDAO.actualizar(usuario);
    }

    // Eliminar usuario
    public boolean eliminarUsuario(int idUsuario) {
        return UsuarioDAO.eliminar(idUsuario);
    }

    // Buscar usuario por ID (opcional)
    public Usuario obtenerUsuarioPorId(int idUsuario) {
        List<Usuario> usuarios = UsuarioDAO.getAll();
        for (Usuario u : usuarios) {
            if (u.getIdUsuario() == idUsuario) {
                return u;
            }
        }
        return null;
    }

    public Usuario verificarLogin(String nombre, String clave) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
