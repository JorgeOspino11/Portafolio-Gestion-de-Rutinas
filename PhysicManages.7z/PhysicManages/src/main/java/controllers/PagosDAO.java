package controllers;

public class PagosDAO {
    
}
