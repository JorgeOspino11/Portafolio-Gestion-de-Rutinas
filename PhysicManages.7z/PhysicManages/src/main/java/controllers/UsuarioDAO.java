package controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import models.Usuario;
import util.Conexion; // Clase que gestiona la conexión a la BD

public class UsuarioDAO {

    public Usuario validarUsuario(String usuario, String clave) {
        Usuario u = null;

        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND clave = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, clave);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                u = new Usuario();
                u.setUsuario(rs.getString("usuario"));
                u.setClave(rs.getString("clave"));
            }

        } catch (SQLException e) {
            System.out.println("Error al validar usuario: " + e.getMessage());
        }

        return u;
    }

    public boolean validarUsuario(Usuario user) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
