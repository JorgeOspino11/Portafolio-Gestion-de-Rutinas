package controllers;

import models.Pagos;
import models.PagosDAO;
import java.util.List;

public class PagoController {
    private final PagosDAO pagoDAO = new PagosDAO();

    /**
     *
     * @param pago
     * @return
     */
    public boolean registrarPago(Pagos pago) {
        return pagoDAO.registrarPago(pago);
    }

    /**
     *
     * @param clienteId
     * @return
     */
    public List<Pagos> obtenerPagosPorCliente(int clienteId) {
        return pagoDAO.obtenerPagosPorCliente(clienteId);
    }

    /**
     *
     * @param pago
     * @return
     */
    public boolean actualizarPago(Pagos pago) {
        return pagoDAO.actualizarPago(pago);
    }

    public boolean eliminarPago(int id) {
        return pagoDAO.eliminarPago(id);
    }
}
