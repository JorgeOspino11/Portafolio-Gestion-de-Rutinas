package controllers;

import models.RutinasDAO;
import java.util.List;
import models.Rutinas;

public class RutinaController {
    private final RutinasDAO rutinaDAO = new RutinasDAO();

    /**
     *
     * @param rutina
     * @return
     */
    public boolean asignarRutina(Rutinas rutina) {
        return RutinasDAO.registrarRutina(rutina);
    }

    /**
     *
     * @param clienteId
     * @return
     */
    public List<Rutinas> obtenerRutinasPorCliente(int clienteId) {
        return rutinaDAO.obtenerRutinasPorCliente(clienteId);
    }

    public boolean actualizarRutina(Rutinas rutina) {
        return rutinaDAO.actualizarRutina(rutina);
    }

    public boolean eliminarRutina(int id) {
        return rutinaDAO.eliminarRutina(id);
    }
}