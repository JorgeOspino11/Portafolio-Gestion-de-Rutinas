package models;

import java.util.Date;

public class Pagos {
    private int id;
    private int clienteId;
    private double monto;
    private Date fecha;

    public Pagos() {}

    public Pagos(int id, int clienteId, double monto, Date fecha) {
        this.id = id;
        this.clienteId = clienteId;
        this.monto = monto;
        this.fecha = fecha;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
}
