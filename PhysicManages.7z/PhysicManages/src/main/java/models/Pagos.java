package models;

public class Pagos {
    
}
