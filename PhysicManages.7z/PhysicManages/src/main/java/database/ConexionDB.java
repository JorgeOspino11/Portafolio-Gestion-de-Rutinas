package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {

    private static final String URL = "jdbc:mysql://localhost:3306/tu_basededatos"; // Reemplaza con el nombre real
    private static final String USER = "root"; // Cambia si tu usuario es diferente
    private static final String PASSWORD = ""; // Coloca tu contraseña de MySQL aquí

    private static Connection connection = null;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Asegúrate de tener el conector JDBC en tu proyecto
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("✅ Conexión exitosa a la base de datos.");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("❌ Error en la conexión: " + e.getMessage());
            }
        }
        return connection;
    }
}
