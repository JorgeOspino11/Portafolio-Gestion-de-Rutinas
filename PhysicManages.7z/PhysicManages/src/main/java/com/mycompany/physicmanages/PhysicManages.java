/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.physicmanages;

/**
 *
 * @author RPR-C80A307ES
 */
public class PhysicManages {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
