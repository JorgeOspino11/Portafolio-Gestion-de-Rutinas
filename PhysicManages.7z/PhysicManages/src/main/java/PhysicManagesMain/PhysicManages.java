package PhysicManagesMain;

public class PhysicManages {

    public static void main(String[] args) {
        System.out.println("Putos");
    }
}
