
package Entidades;
public class polimorfismoAdministrador {
    
}
