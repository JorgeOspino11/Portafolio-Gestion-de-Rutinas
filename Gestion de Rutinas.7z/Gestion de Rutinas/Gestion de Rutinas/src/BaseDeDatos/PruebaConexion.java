package BaseDeDatos;

import java.sql.Connection;
import java.sql.SQLException;

public class PruebaConexion {
    public static void main(String[] args) {
        // Intentar obtener la conexión
        Connection conexion = ConexionBD.getConexion();
        if (conexion != null) {
            System.out.println("¡Conexión exitosa!");
        } else {
            System.out.println("Error en la conexión.");
        }
        // Cerrar la conexión
        ConexionBD.cerrarConexion();
    }
}
