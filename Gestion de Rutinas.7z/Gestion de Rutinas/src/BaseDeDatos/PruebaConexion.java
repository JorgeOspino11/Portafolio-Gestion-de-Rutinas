package BaseDeDatos;

import BaseDeDatos.ConexionBD;
import java.sql.Connection;

public class PruebaConexion {
    public static void main(String[] args) {
        ConexionBD con = new ConexionBD();
        Connection c = con.conectar();
    }
}
