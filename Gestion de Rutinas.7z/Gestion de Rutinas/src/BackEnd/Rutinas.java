package backend;

public class Rutinas {
    private int idRutinas;
    private int idCliente;
    private String descripcion;
    private String nivel;

    public Rutinas() {}

    public Rutinas(int idRutinas, int idCliente, String descripcion, String nivel) {
        this.idRutinas = idRutinas;
        this.idCliente = idCliente;
        this.descripcion = descripcion;
        this.nivel = nivel;
    }

    public int getIdRutina() { return idRutinas; }
    public void setIdRutina(int idRutina) { this.idRutinas = idRutina; }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }
}

