package backend;

public class Pagos {
    private int idPagos;
    private int idCliente;
    private String fechaPago;
    private double monto;

    public Pagos() {}

    public Pagos(int idPagos, int idCliente, String fechaPago, double monto) {
        this.idPagos = idPagos;
        this.idCliente = idCliente;
        this.fechaPago = fechaPago;
        this.monto = monto;
    }

    public int getIdPagos() { return idPagos; }
    public void setIdPagos(int idPagos) { this.idPagos = idPagos; }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public String getFechaPago() { return fechaPago; }
    public void setFechaPago(String fechaPago) { this.fechaPago = fechaPago; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }
}
